---
layout: post
title: 喧闹的悲伤
categories: [My Poems, Depression]
tags: [depression]
---

如果你  
触碰过我  
借以生存的伤痕-  
痛苦的轮廓，  
凝结的时间，  
你也许会原谅我，  
像你原谅  
深秋的街道上  
酒馆里喧闹的悲伤，  
吸烟处寂静的绝望。
