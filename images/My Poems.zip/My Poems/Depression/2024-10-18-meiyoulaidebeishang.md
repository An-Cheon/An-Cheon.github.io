---
layout: post
title: 没有由来的悲伤
categories: [My Poems, Suicide]
tags: [depression, suicide]
---

她站在桥上，  
凝望着无言的汉江，  
没有由来的悲伤  
把她隔绝在世界之外。

思绪在深秋的午后冷却、下坠  
她握着自己的心脏，  
却没有人相信  
她手里鲜红的过往。
