---
layout: post
title: 天快亮了，我必须走了
categories: [My Poems, Suicide]
tags: [depression, suicide]
---

天快亮了，  
我必须走了，  
请告诉夏妮，  
只有和她在一起的时候  
我才没渴望过死亡。
