---
layout: post
title: 伤口已愈合
categories: [My Poems, Depression]
tags: [depression]
---

我一直在受伤，  
就像我手腕上的伤痕一样。  
灵魂破碎，  
但伤口已愈合。

也许你从来没爱过我，  
也许你也说不清，  
也许你只是因为孤独，  
也许在一个人的午夜  
你还会想起我。
