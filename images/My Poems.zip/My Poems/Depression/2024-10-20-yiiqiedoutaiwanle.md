---
layout: post
title: 一切都太晚了
categories: [My Poems, Death]
tags: [depression, death]
---

抑郁在清晨掠过我的灵魂，  
痛苦散落在时间的每一个角落。  
当生活难以承受，  
当那些说过爱我的人已远去，  
我也要走了，  
但是很明显，  
一切都太晚了。  
