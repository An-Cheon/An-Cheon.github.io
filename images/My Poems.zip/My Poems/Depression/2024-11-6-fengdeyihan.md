---
layout: post
title: 风的遗憾
categories: [My Poems, Depression]
tags: [depression, death]
---

我在你的厌倦里坠落，  
流浪在新村喧嚣的孤独里。  
时间是落叶奔流的河，  
不再有你、也不再我有我。  
只是年轻的身体，  
还没来得及随着灵魂死去。  
晚风用早已消失的语言  
唱着千年前的离别。  
我还醒着，  
护士带着镇定剂来了-  
她说她不曾见过时间、  
不曾听过风的遗憾。
