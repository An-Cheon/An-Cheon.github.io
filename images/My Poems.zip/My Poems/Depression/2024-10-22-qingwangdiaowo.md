---
layout: post
title: 请忘掉我
categories: [My Poems, Depression]
tags: [depression]
---

请忘掉我，  
像昨日的雨落在时间里一样。  
请忘掉我，  
像你随手丢弃的回忆一样。  
请忘掉我，  
像工作日里的无人在意的云一样。  
请忘掉我，  
就像我不曾出现，  
今夜无人会因我而遗憾那样。  
