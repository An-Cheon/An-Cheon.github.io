---
layout: post
title: 文字只是我逃避现实的方式
categories: [My Poems, Death]
tags: [depression, death]
---

我没有渴望，也没有未来，  
我不奢求被理解，  
文字只是我逃避现实的方式。  

我在人群中微笑着崩溃，  
假装着理解了他们的话，  
但精神分裂把我和世界隔绝。

当你读到我的文字时，  
那是我在向你问好，  
祝你今天不会想到死亡。
