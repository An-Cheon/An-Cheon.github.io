---
layout: post
title: 痛苦的尽头
categories: [My Poems, Suicide]
tags: [depression, suicide]
---

痛苦尽头的门开了，  
亲爱的，  
我们一起走吧。  
不会再有人  
说我们该死了。
