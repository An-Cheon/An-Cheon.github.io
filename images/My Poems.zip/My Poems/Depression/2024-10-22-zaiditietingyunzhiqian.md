---
layout: post
title: 在地铁停运之前
categories: [My Poems, Depression]
tags: [depression]
---

雨水浇灭了香烟，  
思绪在这一刻回到了现在，  
我在过去徘徊了太久-  
那里有你、有晚风、有失败，  
有那已爬满青苔的未来。  
是时候该回去了-  
在地铁停运之前，  
在夜晚还没开始之前，  
在你再一次闯进我的思绪之前。  
