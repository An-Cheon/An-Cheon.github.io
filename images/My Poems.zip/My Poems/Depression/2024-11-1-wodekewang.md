---
layout: post
title: 我的渴望
categories: [My Poems, Death]
tags: [depression, death]
---

如果你在墓园的角落  
爬满青苔的墓碑旁  
路过我的渴望，  
请不要吵醒她，  
当声音消逝、  
言语被遗忘，  
我和死亡  
已无隔阂。  
