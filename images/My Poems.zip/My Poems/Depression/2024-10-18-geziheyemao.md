---
layout: post
title: 鸽子和野猫
categories: [My Poems, Death]
tags: [depression, death]
---

深秋的晚风吹干了手腕上的静脉血，  
我爱那冰凉的触碰，  
仿佛她是爱我的，  
她吻着我的伤口说着下一轮的故事-  
在我死去的地方会有野菊花、  
会有鸽子和野猫、  
会有大雪也无法掩埋的希望。  
