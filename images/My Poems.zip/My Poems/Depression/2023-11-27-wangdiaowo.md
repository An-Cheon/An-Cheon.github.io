---
layout: post
title: 忘掉我
categories: [My Poems, Suicide]
tags: [depression, suicide]
---

忘掉我，  
轻松地就像  
遗忘每一个街角。

丢掉我，  
就像你抛弃  
每一个过时的玩偶。

只有这样，  
在午夜的天台  
我才不会有牵挂。
