---
layout: post
title: 春天的悲伤
categories: [My Poems, Suicide]
tags: [depression, suicide]
---

在你走后  
悲伤也离开了，  
只有清醒的麻木、  
跳动的心跳违和地存在着。  

冬天的树枝上上吊的人  
在春天的暖阳里腐朽，  
手腕流出的静脉血  
在绝望里浇灌着死亡。  

生活已然破碎，  
只是现在我才意识到  
过往早已如泪水  
消失在雨中。   
