---
layout: post
title: 疲惫的静脉血
categories: [My Poems, Suicide]
tags: [depression, suicide]
---

我不被祝福的身体  
漂流在喧嚣的街道上，  
疲惫的静脉血顺着手腕  
流向时间的深渊。  
在有人自杀的夜里，  
我和绝望深陷在  
这空无一人的孤独里。  
我一生都在讨好，  
直到我变得不再重要。  
直到你忘记我炙热的吻  
和早已冻结的心脏。  
