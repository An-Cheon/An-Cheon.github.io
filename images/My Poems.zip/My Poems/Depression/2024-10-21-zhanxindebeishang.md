---
layout: post
title: 崭新的悲伤
categories: [My Poems, Death]
tags: [depression, death]
---

每一刻我感受到的悲伤，  
都是我以前从未体验过的，  
我把这痛楚写在时间里，  
我知道这是我赖以生存的意义-  
那最痛苦的人  
也能从这遗言里找到安慰。  
每一刻我都在死去，  
在世界对我的恨意里。  
我放弃了怀疑，  
感觉是我接触世界唯一的方式。
