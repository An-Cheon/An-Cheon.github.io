---
layout: post
title: 生命与悲伤的距离
categories: [My Poems, Depression]
tags: [depression]
---

在这被神遗忘的世界里，  
我用身体丈量着生命与悲伤的距离。  
拒绝的微笑在黑夜里下坠，  
浇灭了我淡蓝色的渴望。  
未经允许，  
我被带到这人世。  
而如今，  
这身体于我太过沉重。
