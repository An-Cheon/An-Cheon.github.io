---
layout: post
title: 活下去
categories: [My Poems, Death]
tags: [depression, death]
---

如果你见过  
那清晨的泪痕  
和手腕上深红的绝望，  
你还会忍心说出那句“活下去”吗？

如果你听过  
那无言的悲伤  
和无人在意的祈祷，  
你还会忍心说出那句“活下去”吗？
