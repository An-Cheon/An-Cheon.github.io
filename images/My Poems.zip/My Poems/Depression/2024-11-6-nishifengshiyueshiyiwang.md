---
layout: post
title: 你是风、是月、是遗忘
categories: [My Poems, Depression]
tags: [depression]
---

窗外的你是回忆的倒影，  
匆匆地路过秋日的悲伤。  
生活如落叶随风而散，  
而我们是还未被埋葬的渴望，  
但拥抱已在雨夜里熄灭。  
你是风、是月、是遗忘，  
也是在迷宫里寻找自己的人。
