---
layout: post
title: 吗啡过量
categories: [My Poems, Suicide]
tags: [depression, suicide]
---

吗啡过量之后-  
洗胃、血液灌流，  
再次醒来已经是两天后，  
我想看一眼账单-  
看一看通向深渊的船票。  

我已经醒来，  
但还被安排在ICU-  
对于一个穷人来说  
这是真正的死亡。  
我想拔掉股动脉里的导管，  
我害怕在医院里再一次被抢救。  
