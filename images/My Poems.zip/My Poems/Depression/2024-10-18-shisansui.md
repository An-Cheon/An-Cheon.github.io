---
layout: post
title: 十三岁
categories: [My Poems, Death]
tags: [depression, death]
---

我不会失望-  
我早已摒弃了希望。  
我不会失败-  
我已败给了生活。  
我不会受伤-  
十三岁时我就已死去。
