---
layout: post
title: 你的灵魂怎么了？
categories: [My Poems, Depression]
tags: [depression]
---

你的灵魂怎么了？  
透过淡粉色的阳光，  
我在你的微笑里  
看到了悲伤和泪痕。  
他不配触碰你的画布，  
你怎么忘了-  
你就是艺术。
