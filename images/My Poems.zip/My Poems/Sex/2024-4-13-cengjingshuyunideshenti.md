---
layout: post
title: 曾经属于你的身体
categories: [My Poems, Sex]
tags: [sex, depression, death]
---

今夜我将再一次死去，  
在连猫也找不到的角落里，  
我触摸着那曾经属于你的身体-  
迷路的手指在肌肤上徘徊，  
我闭上眼睛，  
想起你掐住我脖子时的温柔。
