---
layout: post
title: 春天的故事
categories: [My Poems, Sex]
tags: [sex, depression]
---

你走了，流浪在她的床上，  
我确信，我早已被你遗忘，  
但是亲爱的，  
那些你曾说过只对我说的话，  
你又一次只对她说了吗？  

在初秋的首尔，  
我一个人坐在狎鸥亭的街角-  
你说这里有你最爱的咖啡店-  
听秋叶诉说春天的故事。  
