---
layout: post
title: 当我们不再交谈
categories: [My Poems, Sex]
tags: [sex, love]
---

当你谈到爱的时候  
我知道，你要谈的是性。  
当你谈到性的时候  
我知道，你已经厌倦了交谈。  
当我们不再交谈  
我知道，我应该脱光衣服了。  
