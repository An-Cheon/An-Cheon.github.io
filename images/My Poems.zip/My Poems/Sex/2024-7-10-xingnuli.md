---
layout: post
title: 性奴隶
categories: [My Poems, Sex]
tags: [sex, depression]
---

我是你的性奴隶-  
只是、  
也只能是性奴隶，  
不是爱奴隶。  

像往常一样，  
今天我又被生活强暴，  
没有爱，  
没有情感，  
只有被生活强暴这件事。  
