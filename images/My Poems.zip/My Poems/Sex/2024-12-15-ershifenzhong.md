---
layout: post
title: 二十分钟
categories: [My Poems, Sex]
tags: [depression, sex, love, suicide]
---

烛光漫不经心地撩过你的脸，  
在墙壁上的阴影里  
十九岁时的我们沉默不语，  
如现在一样毫无意义-  
我们又滚落到了深渊。  

今夜你的欲望只有二十分钟，  
但我们的时间不够了，  
忘掉我，  
忘掉早已燃尽的热烈，  
就像你遗忘每一条曲线。  
但我还想带你回家，  
我已经攒了半年安眠药。  
