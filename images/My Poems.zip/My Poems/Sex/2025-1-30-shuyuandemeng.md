---
layout: post
title: 疏远的梦
categories: [My Poems, Sex]
tags: [depression, sex, love]
---

我们厌倦了彼此，  
我们无力分离，  
所以我们还睡在同一张床，  
做着日渐疏远的梦，  
把还未分手的状态叫做相爱。
