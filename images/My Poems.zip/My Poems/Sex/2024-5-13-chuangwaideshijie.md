---
layout: post
title: 在我放弃生命之前
categories: [My Poems, Sex]
tags: [sex, depression]
---

我还活着  
被生活强奸，  
以不同的姿势、心情，  
从郊外的空地  
到下午拥挤的地铁。  
我在地铁上流泪，  
望着窗外冰凉的世界，  
邻座的人离开了座位-  
像我曾遇到的所有人一样。
