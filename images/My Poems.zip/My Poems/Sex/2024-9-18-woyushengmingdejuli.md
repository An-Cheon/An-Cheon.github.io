---
layout: post
title: 我与生命的距离
categories: [My Poems, Sex]
tags: [sex, depression]
---

她张开双腿  
把我的手拉向生命的源头，  
而我与生命的距离却如此遥远。  
我从未理解过她的欲望，  
作为一个局外人，  
沉默是我的告白。  
