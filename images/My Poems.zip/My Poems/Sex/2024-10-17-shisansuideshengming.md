---
layout: post
title: 十三岁的生命
categories: [My Poems, Sex]
tags: [sex, depression]
---

在我开始流浪之前，  
就已经被命运放逐。  
十三岁时的沙发上，  
我全部的生命  
随着大腿上的精液流走了。  
我对性从未有过渴望-  
我所有的抗拒、拒绝和叫喊  
都来自那过早成熟的童年，  
虽然性，  
是我如今唯一的谋生方式…  
